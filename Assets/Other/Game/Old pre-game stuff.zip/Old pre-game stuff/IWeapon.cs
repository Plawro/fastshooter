public interface IWeapon
{
    void Primary();
    void Secondary();
    void Reload();
}
